var { AGCClient, CredentialParser } = require("@agconnect/common-server");
const {AGCFunction} = require("@agconnect/function-server");


var credential = CredentialParser.toCredential("./agc-apiclient-912931775108369536-7108610245037015320.json");
AGCClient.initialize(credential);

async function handler(){
    let agcClient = AGCClient.getInstance();
    let agcFunction = new AGCFunction(agcClient);
    console.log("-function: "+JSON.stringify(agcFunction));
    let callable = agcFunction.wrap("testfunction", "$latest");
    
    // try {
    //     let res = await callable.call();
    //     console.log(res.getValue());
    // } catch (error) {
    //     console.error("-------abnormal-------");
    //     console.log(error);
    // }
}

handler().then(()=>{
    console.log("after handler");
});



